import hashlib
import logging
import sqlite3
import os


def generate_salt():
    salt = os.urandom(16)
    return salt


def check_password():
    logging.info("Verifying password.")
    log = input("Write your login: ")
    pas = input("Write your password: ")
    con = sqlite3.connect('login.db')
    cursor = con.cursor()
    cursor.execute("SELECT hash FROM login WHERE username = ?", [log])
    hashcheck = cursor.fetchone()[0]
    cursor.execute("SELECT salt FROM login WHERE username = ?", [log])
    saltcheck = cursor.fetchone()[0]
    new_hash = hashlib.pbkdf2_hmac('sha256', pas.encode('utf-8'), saltcheck, 10000)
    if hashcheck == new_hash:
        print("Password is correct.")
    else:
        logging.error("Password is not correct")


class login:
    def __init__(self, log, pas):
        self._log = log
        self._pas = pas

    def set_log(self, l):
        if isinstance(l, str):
            self._log = l
        else:
            raise TypeError("Login must be string type.")

    def get_log(self):
        return self._log

    def set_pas(self, p):
        if isinstance(p, str):
            self._pas = p
        else:
            raise TypeError("Password must be string type.")

    def get_pas(self):
        return self._pas

    def register(self):
        s = generate_salt()
        h = hashlib.pbkdf2_hmac('sha256', self._pas.encode('utf-8'), s, 10000)
        con = sqlite3.connect('login.db')
        cursor = con.cursor()
        cursor.execute("INSERT INTO login (username, hash, salt) VALUES (?, ?, ?)", (self._log, h, s))
        con.commit()

    pas = property(get_pas, set_pas)
    log = property(get_log, set_log)
