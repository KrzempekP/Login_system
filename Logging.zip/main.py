from Logging import login, check_password
import sqlite3
import logging


def create_table():
    con = sqlite3.connect('login.db')
    cursor = con.cursor()
    query = "CREATE TABLE login(username VARCHAR UNIQUE, hash VARCHAR, salt VARCHAR)"
    cursor.execute(query)


def display_elements():
    con = sqlite3.connect('login.db')
    cursor = con.cursor()
    query = "SELECT * FROM login"
    cursor.execute(query)
    print(cursor.fetchall())


if __name__ == '__main__':

    l = input("Login: ")
    p1 = input("Password: ")
    p2 = input("Password again: ")
    if p1 == p2:
        log = login(l, p1)
        log.register()
    else:
        logging.error("Passwords are not the same.")

    check_password()

    display_elements()

